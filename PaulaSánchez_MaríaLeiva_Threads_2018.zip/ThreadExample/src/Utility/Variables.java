package Utility;

public class Variables {
    
    public static final int WIDTH = 830;
    public static final int HEIGHT = 703;
    public static final int SPEED = 70;
}